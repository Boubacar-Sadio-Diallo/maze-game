var indexSectionsWithContent =
{
  0: "acghlmnpsty¨",
  1: "clps¨",
  2: "ps",
  3: "acgl",
  4: "achlmnpsty"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Structures de données",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables"
};

