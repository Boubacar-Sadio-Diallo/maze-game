var structplayer =
[
    [ "has_key", "structplayer.html#a7f91b47ff23313f9cc5524d5eb0169dc", null ],
    [ "moves", "structplayer.html#a8fa0f7b709ba23cefc7f6a220466c6ee", null ],
    [ "position", "structplayer.html#a1d1f3f7c1b08cf7b359cec5225ea79c9", null ],
    [ "score", "structplayer.html#aae006b871accd2a0b010783a8f56e9de", null ]
];