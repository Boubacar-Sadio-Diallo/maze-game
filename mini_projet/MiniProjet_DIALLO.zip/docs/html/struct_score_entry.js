var struct_score_entry =
[
    [ "moves", "struct_score_entry.html#a3d70f07f97469b544788ae209349a640", null ],
    [ "nom", "struct_score_entry.html#a7350293c65303456d9403b7729123015", null ],
    [ "score_final", "struct_score_entry.html#a5a264456436213bc2b325abd868e74b6", null ]
];