var searchData=
[
  ['¨player_0',['¨Player',['../struct_xC2_xA8_player.html',1,'']]]
];
