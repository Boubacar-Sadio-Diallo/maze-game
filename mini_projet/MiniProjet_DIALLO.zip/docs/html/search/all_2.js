var searchData=
[
  ['generer_5fnom_5ffichier_5fscore_0',['generer_nom_fichier_score',['../score_8c.html#a63d97a48ae9df3b4787e4cb55291763e',1,'score.c']]],
  ['gerer_5fhighscore_1',['gerer_highscore',['../score_8c.html#a35d090e8fe8e58d5d562c224b365b53d',1,'score.c']]]
];
