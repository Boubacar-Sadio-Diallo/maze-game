var searchData=
[
  ['scoreentry_0',['ScoreEntry',['../struct_score_entry.html',1,'']]]
];
