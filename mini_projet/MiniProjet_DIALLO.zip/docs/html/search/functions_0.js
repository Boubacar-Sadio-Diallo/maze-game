var searchData=
[
  ['afficher_5fscores_0',['afficher_scores',['../score_8c.html#a2fdf49ba70627c3877ad425992e26ded',1,'score.c']]]
];
