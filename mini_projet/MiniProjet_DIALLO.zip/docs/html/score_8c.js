var score_8c =
[
    [ "afficher_scores", "score_8c.html#a2fdf49ba70627c3877ad425992e26ded", null ],
    [ "generer_nom_fichier_score", "score_8c.html#a63d97a48ae9df3b4787e4cb55291763e", null ],
    [ "gerer_highscore", "score_8c.html#a35d090e8fe8e58d5d562c224b365b53d", null ]
];