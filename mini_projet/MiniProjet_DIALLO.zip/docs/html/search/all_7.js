var searchData=
[
  ['player_0',['player',['../structplayer.html',1,'']]],
  ['player_2ec_1',['player.c',['../player_8c.html',1,'']]],
  ['position_2',['Position',['../struct_position.html',1,'']]],
  ['position_3',['position',['../structplayer.html#a1d1f3f7c1b08cf7b359cec5225ea79c9',1,'player']]]
];
