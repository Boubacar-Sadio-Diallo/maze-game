var player_8c =
[
    [ "creerJoueur", "player_8c.html#afc93dad7ba8864fee8ffff0422d32034", null ],
    [ "libererJoueur", "player_8c.html#ae7efb9bad80eedac8a37a7ca9da10178", null ]
];