var searchData=
[
  ['player_0',['player',['../structplayer.html',1,'']]],
  ['position_1',['Position',['../struct_position.html',1,'']]]
];
