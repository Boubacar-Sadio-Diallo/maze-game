var searchData=
[
  ['moves_0',['moves',['../structplayer.html#a8fa0f7b709ba23cefc7f6a220466c6ee',1,'player::moves'],['../struct_score_entry.html#a3d70f07f97469b544788ae209349a640',1,'ScoreEntry::moves']]]
];
