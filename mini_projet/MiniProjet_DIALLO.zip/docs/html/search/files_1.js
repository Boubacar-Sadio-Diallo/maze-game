var searchData=
[
  ['score_2ec_0',['score.c',['../score_8c.html',1,'']]]
];
